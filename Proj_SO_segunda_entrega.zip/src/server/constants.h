#ifndef CONSTANTS_H
#define CONSTANTS_H

#define MAX_WRITE_SIZE 256
#define MAX_STRING_SIZE 40
#define MAX_JOB_FILE_NAME_SIZE 256

#define S 3//Variavel arbitraria que define o limite de 
//sessões que o servidor pode ter em simultaneo

#endif //CONSTANTS_H